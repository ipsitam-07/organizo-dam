import fs from 'fs';
import path from 'path';
import os from 'os';
import * as tus from 'tus-js-client';

// 1. PASTE YOUR POSTMAN/SWAGGER TOKEN HERE
const JWT_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImE5YzhiNzQ2LTIzODMtNDgxZi04NzlhLTg3ZmU2MDk1NGI1YyIsImVtYWlsIjoidGVzdEBleGFtcGxlLmNvbSIsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzcyNDQ5Mjk2LCJleHAiOjE3NzI0NDkzODJ9.rylHXd9I_L8Bpr5jL2YcDduLZvhJ351ycMUM2InTPw8'; 

const filePath = path.join(os.tmpdir(), 'organizo-dummy-video.mp4');
const buffer = Buffer.alloc(15 * 1024 * 1024, 'DAM_DATA_CHUNK_'); // Creates a 15MB file
fs.writeFileSync(filePath, buffer);

console.log(`[Test] Created 15MB test file at ${filePath}`);

const file = fs.createReadStream(filePath);
const size = fs.statSync(filePath).size;

const options: tus.UploadOptions = {
  endpoint: 'http://localhost:3002/api/upload',
  metadata: {
    filename: 'organizo-dummy-video.mp4',
    filetype: 'video/mp4',
  },
  headers: {
    Authorization: `Bearer ${JWT_TOKEN}`, // Secure route access
  },
  uploadSize: size,
  chunkSize: 5 * 1024 * 1024, // Send in 5MB chunks
  onError(error) {
    console.error('[Test] Upload failed:', error);
  },
  onProgress(bytesUploaded, bytesTotal) {
    const percentage = ((bytesUploaded / bytesTotal) * 100).toFixed(2);
    console.log(`[Test] Uploaded ${bytesUploaded} of ${bytesTotal} bytes (${percentage}%)`);
  },
  onSuccess() {
    console.log('[Test] Upload completely finished!');
    console.log(`[Test] MinIO File URL: ${upload.url}`);
    fs.unlinkSync(filePath); // Clean up the temp file
  },
};

const upload = new tus.Upload(file, options);
console.log('[Test] Starting authenticated chunked upload...');
upload.start();